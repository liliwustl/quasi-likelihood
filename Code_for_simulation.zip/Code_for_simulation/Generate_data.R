library(MASS)
Generate_data=function(m,group,distribution,T){
  p=2 ##p is the dimension of beta
  if(group==3){
  set.seed(1234+T)
  c1=m*0.1
  c2=m*0.2
  a1=-1
  a2=1
  atrue=c(rep(a1,c1),rep(0,m-c1-c2),rep(a2,c2))
  }else if(group==5){
    set.seed(124+T)
    c1=c2=c3=c4=m*0.1
    a1=-2
    a2=-1
    a3=1
    a4=2
    atrue=c(rep(a1,c1),rep(a2,c2),rep(0,m-c1-c2-c3-c4),rep(a3,c3),rep(a4,c4)) 
  }
  ni=round(runif(m,90,100))
  N=sum(ni)
  beta=c(0.2,0.2)
  J1=matrix(rep(1:p,times=p),byrow=FALSE, nrow=p)
  K1=matrix(rep(1:p,times=p),byrow=TRUE, nrow=p)
  sigma=0.2^abs(J1-K1)
  X=mvrnorm(N,rep(0,p),sigma)
  Z=matrix(0,N,m)
  id=NULL
  a=NULL
  for(k in 1:m){
    Z[(sum(ni[(1:m)<k])+1):(sum(ni[(1:m)<k])+ni[k]),k]=rep(1,ni[k])
    id=c(id,rep(k,ni[k]))
    a=c(a,rep(atrue[k],ni[k]))
  }
  ax=as.vector(Z%*%atrue+X%*%beta)
  if(distribution=="poisson"){
    Y=rpois(N,exp(ax))
  } else if(distribution=="logistic"){
    Y=rbinom(N,1,exp(ax)/(1+exp(ax)))
  } else if(distribution== "negative binomial"){
    Y = rnbinom(N, size = 0.5, mu = exp(ax))
  } else {
    stop("Unknown distribution")
  }
  data=as.data.frame(cbind(id,X,Y,a))
  names(data)=c("id","X1","X2","Y","a")
  if(group==3){
  write.csv(data,paste("Simulated_data/", distribution, "-", m, "/","Data-", T, ".csv", sep = ""),row.names=F)
  }else if(group==5){
  write.csv(data,paste("Simulated_data/", group,"groups","-", m, "/","Data-", T, ".csv", sep = ""),row.names=F)
  }
}
for(T in 1:100){
Generate_data(m=50,group=3,distribution="poisson",T)
Generate_data(m=50,group=3,distribution="negative binomial",T)
Generate_data(m=50,group=3,distribution="logistic",T)
Generate_data(m=50,group=5,distribution="poisson",T)
Generate_data(m=100,group=3,distribution="poisson",T)
Generate_data(m=100,group=3,distribution="negative binomial",T)
Generate_data(m=100,group=3,distribution="logistic",T)
Generate_data(m=100,group=5,distribution="poisson",T)
}