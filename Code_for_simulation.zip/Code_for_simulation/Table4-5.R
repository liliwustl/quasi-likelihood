rm(list=ls())
library(MASS)
library(lme4)
library(nlme)
library(readxl)
library(npmlreg)
library(dplyr)
pval=function(est,se){
  ratio=est/se
  pvalue=2*pnorm(-abs(ratio))
  return(pvalue)
}

 load('Results/Application/intermediate_results.Rdata')
  ngroup=save_res$ngroup
  ngroup_np=save_res$ngroup_np
  betaest=save_res$betaest
  se.beta=save_res$se.beta
  Aest=save_res$Aest
  se.a=save_res$se.a
  num=save_res$num
  betaran=save_res$betaran
  se.beta_ran=save_res$se.beta_ran
  betafix=save_res$betafix
  se.beta_fix=save_res$se.beta_fix
  betanp=save_res$betanp
  se.beta_np=save_res$se.beta_np
  SRRhat=save_res$SRRhat
  Pv.a=pval(Aest,se.a)
  Pv.beta=pval(betaest,se.beta)
  Pv.beta_np=pval(betanp,se.beta_np)
  Pv.beta_ran=pval(betaran,se.beta_ran)
  Pv.beta_fix=pval(betafix,se.beta_fix)
  



Variable <- c("Time on ESRD", "< 1 years", "1-5 years", "> 5 years", "Donor age", "< 15", "15-30", "30-45", "45-60", "> 60",
              "Donor race", "White", "Black", "Asian", "Donor gender", "Donor BMI", "Normal", "Under", "Over", "Obesity", 
              "DON-HTN", "DON-EC", "Recipient gender", "Recipient race", "White", "Black", "Asian", "REC-DIAB", "Type I", 
              "Type II", "Recipient BMI", "Normal", "Under", "Over", "Obesity", "REC-PREV-KI", "REC-COLD-ISCH", "REC-AGE",
              "18-35", "35-50", "50-60", "60-70", "> 70")
SCAD_Est=c(NA,"Ref",betaest[1],betaest[2],NA,betaest[3],betaest[4],"Ref",betaest[5],betaest[6],NA,"Ref",betaest[7],betaest[8],
           betaest[25],NA,"Ref",betaest[26],betaest[27],betaest[28],betaest[9],betaest[10],betaest[11],NA,"Ref",
           betaest[12],betaest[13],NA,betaest[23],betaest[24],NA,"Ref",betaest[14],betaest[15],betaest[16],betaest[17],
           betaest[18],NA,betaest[19],betaest[20],"Ref",betaest[21],betaest[22])
SCAD_SE=c(NA,"Ref",se.beta[1],se.beta[2],NA,se.beta[3],se.beta[4],"Ref",se.beta[5],se.beta[6],NA,"Ref",se.beta[7],se.beta[8],
          se.beta[25],NA,"Ref",se.beta[26],se.beta[27],se.beta[28],se.beta[9],se.beta[10],se.beta[11],NA,"Ref",
          se.beta[12],se.beta[13],NA,se.beta[23],se.beta[24],NA,"Ref",se.beta[14],se.beta[15],se.beta[16],se.beta[17],
          se.beta[18],NA,se.beta[19],se.beta[20],"Ref",se.beta[21],se.beta[22])
SCAD_P_value=c(NA,"Ref",Pv.beta[1],Pv.beta[2],NA,Pv.beta[3],Pv.beta[4],"Ref",Pv.beta[5],Pv.beta[6],NA,"Ref",Pv.beta[7],Pv.beta[8],
               Pv.beta[25],NA,"Ref",Pv.beta[26],Pv.beta[27],Pv.beta[28],Pv.beta[9],Pv.beta[10],Pv.beta[11],NA,"Ref",
               Pv.beta[12],Pv.beta[13],NA,Pv.beta[23],Pv.beta[24],NA,"Ref",Pv.beta[14],Pv.beta[15],Pv.beta[16],Pv.beta[17],
               Pv.beta[18],NA,Pv.beta[19],Pv.beta[20],"Ref",Pv.beta[21],Pv.beta[22])
FE_Est=c(NA,"Ref",betafix[1],betafix[2],NA,betafix[3],betafix[4],"Ref",betafix[5],betafix[6],NA,"Ref",betafix[7],betafix[8],
         betafix[25],NA,"Ref",betafix[26],betafix[27],betafix[28],betafix[9],betafix[10],betafix[11],NA,"Ref",
         betafix[12],betafix[13],NA,betafix[23],betafix[24],NA,"Ref",betafix[14],betafix[15],betafix[16],betafix[17],
         betafix[18],NA,betafix[19],betafix[20],"Ref",betafix[21],betafix[22])
FE_SE=c(NA,"Ref",se.beta_fix[1],se.beta_fix[2],NA,se.beta_fix[3],se.beta_fix[4],"Ref",se.beta_fix[5],se.beta_fix[6],NA,"Ref",se.beta_fix[7],se.beta_fix[8],
        se.beta_fix[25],NA,"Ref",se.beta_fix[26],se.beta_fix[27],se.beta_fix[28],se.beta_fix[9],se.beta_fix[10],se.beta_fix[11],NA,"Ref",
        se.beta_fix[12],se.beta_fix[13],NA,se.beta_fix[23],se.beta_fix[24],NA,"Ref",se.beta_fix[14],se.beta_fix[15],se.beta_fix[16],se.beta_fix[17],
        se.beta_fix[18],NA,se.beta_fix[19],se.beta_fix[20],"Ref",se.beta_fix[21],se.beta_fix[22])
FE_P_value=c(NA,"Ref",Pv.beta_fix[1],Pv.beta_fix[2],NA,Pv.beta_fix[3],Pv.beta_fix[4],"Ref",Pv.beta_fix[5],Pv.beta_fix[6],NA,"Ref",Pv.beta_fix[7],Pv.beta_fix[8],
             Pv.beta_fix[25],NA,"Ref",Pv.beta_fix[26],Pv.beta_fix[27],Pv.beta_fix[28],Pv.beta_fix[9],Pv.beta_fix[10],Pv.beta_fix[11],NA,"Ref",
             Pv.beta_fix[12],Pv.beta_fix[13],NA,Pv.beta_fix[23],Pv.beta_fix[24],NA,"Ref",Pv.beta_fix[14],Pv.beta_fix[15],Pv.beta_fix[16],Pv.beta_fix[17],
             Pv.beta_fix[18],NA,Pv.beta_fix[19],Pv.beta_fix[20],"Ref",Pv.beta_fix[21],Pv.beta_fix[22])
RE_Est=c(NA,"Ref",betaran[1],betaran[2],NA,betaran[3],betaran[4],"Ref",betaran[5],betaran[6],NA,"Ref",betaran[7],betaran[8],
         betaran[25],NA,"Ref",betaran[26],betaran[27],betaran[28],betaran[9],betaran[10],betaran[11],NA,"Ref",
         betaran[12],betaran[13],NA,betaran[23],betaran[24],NA,"Ref",betaran[14],betaran[15],betaran[16],betaran[17],
         betaran[18],NA,betaran[19],betaran[20],"Ref",betaran[21],betaran[22])
RE_SE=c(NA,"Ref",se.beta_ran[1],se.beta_ran[2],NA,se.beta_ran[3],se.beta_ran[4],"Ref",se.beta_ran[5],se.beta_ran[6],NA,"Ref",se.beta_ran[7],se.beta_ran[8],
        se.beta_ran[25],NA,"Ref",se.beta_ran[26],se.beta_ran[27],se.beta_ran[28],se.beta_ran[9],se.beta_ran[10],se.beta_ran[11],NA,"Ref",
        se.beta_ran[12],se.beta_ran[13],NA,se.beta_ran[23],se.beta_ran[24],NA,"Ref",se.beta_ran[14],se.beta_ran[15],se.beta_ran[16],se.beta_ran[17],
        se.beta_ran[18],NA,se.beta_ran[19],se.beta_ran[20],"Ref",se.beta_ran[21],se.beta_ran[22])
RE_P_value=c(NA,"Ref",Pv.beta_ran[1],Pv.beta_ran[2],NA,Pv.beta_ran[3],Pv.beta_ran[4],"Ref",Pv.beta_ran[5],Pv.beta_ran[6],NA,"Ref",Pv.beta_ran[7],Pv.beta_ran[8],
             Pv.beta_ran[25],NA,"Ref",Pv.beta_ran[26],Pv.beta_ran[27],Pv.beta_ran[28],Pv.beta_ran[9],Pv.beta_ran[10],Pv.beta_ran[11],NA,"Ref",
             Pv.beta_ran[12],Pv.beta_ran[13],NA,Pv.beta_ran[23],Pv.beta_ran[24],NA,"Ref",Pv.beta_ran[14],Pv.beta_ran[15],Pv.beta_ran[16],Pv.beta_ran[17],
             Pv.beta_ran[18],NA,Pv.beta_ran[19],Pv.beta_ran[20],"Ref",Pv.beta_ran[21],Pv.beta_ran[22])
LC_Est=c(NA,"Ref",betanp[1],betanp[2],NA,betanp[3],betanp[4],"Ref",betanp[5],betanp[6],NA,"Ref",betanp[7],betanp[8],
         betanp[25],NA,"Ref",betanp[26],betanp[27],betanp[28],betanp[9],betanp[10],betanp[11],NA,"Ref",
         betanp[12],betanp[13],NA,betanp[23],betanp[24],NA,"Ref",betanp[14],betanp[15],betanp[16],betanp[17],
         betanp[18],NA,betanp[19],betanp[20],"Ref",betanp[21],betanp[22])
LC_SE=c(NA,"Ref",se.beta_np[1],se.beta_np[2],NA,se.beta_np[3],se.beta_np[4],"Ref",se.beta_np[5],se.beta_np[6],NA,"Ref",se.beta_np[7],se.beta_np[8],
        se.beta_np[25],NA,"Ref",se.beta_np[26],se.beta_np[27],se.beta_np[28],se.beta_np[9],se.beta_np[10],se.beta_np[11],NA,"Ref",
        se.beta_np[12],se.beta_np[13],NA,se.beta_np[23],se.beta_np[24],NA,"Ref",se.beta_np[14],se.beta_np[15],se.beta_np[16],se.beta_np[17],
        se.beta_np[18],NA,se.beta_np[19],se.beta_np[20],"Ref",se.beta_np[21],se.beta_np[22])
LC_P_value=c(NA,"Ref",Pv.beta_np[1],Pv.beta_np[2],NA,Pv.beta_np[3],Pv.beta_np[4],"Ref",Pv.beta_np[5],Pv.beta_np[6],NA,"Ref",Pv.beta_np[7],Pv.beta_np[8],
             Pv.beta_np[25],NA,"Ref",Pv.beta_np[26],Pv.beta_np[27],Pv.beta_np[28],Pv.beta_np[9],Pv.beta_np[10],Pv.beta_np[11],NA,"Ref",
             Pv.beta_np[12],Pv.beta_np[13],NA,Pv.beta_np[23],Pv.beta_np[24],NA,"Ref",Pv.beta_np[14],Pv.beta_np[15],Pv.beta_np[16],Pv.beta_np[17],
             Pv.beta_np[18],NA,Pv.beta_np[19],Pv.beta_np[20],"Ref",Pv.beta_np[21],Pv.beta_np[22])

sink("Results/Table4.csv",append=FALSE,split=TRUE)
Table4=data.frame(Variable,SCAD_Est, SCAD_SE, SCAD_P_value,FE_Est, FE_SE, FE_P_value,RE_Est, RE_SE,RE_P_value,
                   LC_Est,LC_SE, LC_P_value)
cat("\n### Table 4 in Application ###\n")
print(Table4)
sink()

sink("Results/Table5.csv",append=FALSE,split=TRUE)
Table5 <- data.frame(
  Variable = c("Est", "num", "SE", "P-value", "SER"),
  Delta_1 = c(Aest[1], num[1], se.a[1], Pv.a[1], SRRhat[1]),
  Delta_2 = c("ref",  num[2], se.a[2],  Pv.a[2], SRRhat[2]),
  Delta_3 = c(Aest[3], num[3], se.a[3], Pv.a[3], SRRhat[3]),
  stringsAsFactors = FALSE
)
cat("\n### Table 5 in Application ###\n")
print(Table5)
sink()


